# Quick Use — Minecraft 1.21.11 Fabric (source project)

This is a small client-side Fabric mod project intended for Minecraft Java 1.21.11.

## What it does
- Adds nine configurable keybinds, one for each hotbar slot.
- Hold a slot's Quick Use key to temporarily select that slot and trigger the normal right-click item action once.
- Keep holding the key while an item needs time to be used (for example, food or a potion).
- Release the key to return to the previously selected hotbar slot.
- Keybinds start unassigned: configure them in **Options → Controls → Key Binds → Quick Use**.

## Important limitations
- This is a **source project**, not a precompiled `.jar`; it has not been compiled or tested in-game here.
- The mod uses the game's normal client interaction. Server rules, cooldowns, item behavior, and anti-cheat may affect use.
- Keep the key held until a consumable finishes; releasing early restores your original slot and may interrupt the action.
- Only one Quick Use key should be held at a time.
- Fabric Loader and Fabric API for Minecraft 1.21.11 are required. This project targets Java 21.

## Build into a .jar
On a computer with Java 21 and internet access:
1. Install Gradle 8.14+ (or use a Gradle wrapper).
2. Open this folder in a terminal.
3. Run `gradle build`.
4. The output should be under `build/libs/quickuse-1.0.0.jar`.
5. Copy that jar to `.minecraft/mods` or PojavLauncher's instance `mods` folder.

If Gradle reports that the Loom version cannot be resolved, change the `fabric-loom` version in `build.gradle` to a released Loom version compatible with your installed Gradle.
