package io.quickuse;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import org.lwjgl.glfw.GLFW;

public final class QuickUseClient implements ClientModInitializer {
    private static final KeyMapping[] QUICK_KEYS = new KeyMapping[9];

    private int activeSlot = -1;
    private int originalSlot = -1;
    private boolean actionStarted = false;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("quickuse", "main")
        );

        for (int i = 0; i < QUICK_KEYS.length; i++) {
            QUICK_KEYS[i] = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                    "key.quickuse.slot" + (i + 1),
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_UNKNOWN,
                    category
            ));
        }

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(Minecraft client) {
        if (client.player == null || client.gameMode == null || client.screen != null) {
            restore(client);
            return;
        }

        int requestedSlot = -1;
        for (int i = 0; i < QUICK_KEYS.length; i++) {
            if (QUICK_KEYS[i].isDown()) {
                requestedSlot = i;
                break;
            }
        }

        if (requestedSlot == -1) {
            restore(client);
            return;
        }

        if (activeSlot != requestedSlot) {
            restore(client);
            if (client.player.getInventory().getItem(requestedSlot).isEmpty()) {
                return;
            }

            originalSlot = client.player.getInventory().selected;
            activeSlot = requestedSlot;
            client.player.getInventory().selected = requestedSlot;
            actionStarted = false;
        }

        // Trigger the normal right-click item interaction once per key hold.
        // Keeping the key held keeps the selected slot active, so food/potions
        // can finish their normal use animation. Releasing the key restores
        // the slot that was selected before Quick Use began.
        if (!actionStarted) {
            client.gameMode.useItem(client.player, InteractionHand.MAIN_HAND);
            actionStarted = true;
        }
    }

    private void restore(Minecraft client) {
        if (activeSlot != -1 && client.player != null && originalSlot >= 0) {
            client.player.getInventory().selected = originalSlot;
        }
        activeSlot = -1;
        originalSlot = -1;
        actionStarted = false;
    }
}
